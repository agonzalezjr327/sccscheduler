module.exports = {
    mongoURI: 'mongodb://localhost/SCCDATABASE'
}