import moment from "moment";

// Check for class room conflicts
export const checkClassConflict = (startDate, startTime, endDate, endTime, classroom, allClassRooms, days) => {
  let scheduledDays = [];
  let conflictedDate = []
  let classDayInProgress = []

  const getDatesBetweenDates = (startingDate, endingDate) => {
    endingDate = new Date(endingDate)
    let dates = []
    //to avoid modifying the original date
    const theDate = new Date(startingDate)
    while (theDate < endingDate) {
      dates = [...dates, new Date(theDate)]
      theDate.setDate(theDate.getDate() + 1)
    }
    dates = [...dates, endingDate]
    return dates
  }

  days = days?.map(d => d.slice(0, 3))
  // gets all classes in the room selected
  let selectedRoomClasses = allClassRooms.filter(
    (room) => room.classroom === classroom
  );

  selectedRoomClasses.forEach(room => {
    let format = 'hh:mm:ss'
    let sTime = moment(startTime, format)
    let eTime = moment(endTime, format)

    // all class times in classroom selected
    let beforeTime = moment(room.startTime, format)
    let afterTime = moment(room.endTime, format)

    // checking if start time or end time conflicts
    if (sTime.isBetween(beforeTime, afterTime) || eTime.isBetween(beforeTime, afterTime) || sTime.format(format) === beforeTime.format(format)) {
      
      // gets all days in range of class in session
      let classInSession = getDatesBetweenDates(room.startDate, room.endDate);

      // gets all days in range of class to be scheduled
      let classToSchedule = getDatesBetweenDates(startDate, endDate);
      let roomDays = room.days.map(d => d.slice(0, 3))

      //checking range in session, only pushing the actual days that classes are on
      classInSession.map(c => {
        c = c.toString()
        return roomDays.map(r => c.includes(r) ? classDayInProgress.push(c) : null)
      })

      // checking the days the class to be scheduled and only pushing the actual days out of the range
      classToSchedule?.map(c => {
        return days?.map(d => c.toString().includes(d) ? scheduledDays.push(c) : null)
      })

      // checking the actual days to be scheduled against the days that the class are in session and pushing the conflicts
      classDayInProgress.map(c => {
        return scheduledDays.map(d => d.toString() === c.toString() ? conflictedDate.push({class: room.classname, date: new Date(d).toDateString()}) : null)
      })
    }
  })

  return conflictedDate
}


// Check for student Conflicts with all other classes
export const checkStudentConflict = (startDate, startTime, endDate, endTime, days, tradeStudentsId, data) => {
  
  let allStudents = [];
  let scheduledDays = [];
  let conflictedDate = []
  let classDayInProgress = []

  const getDatesBetweenDates = (startingDate, endingDate) => {
    endingDate = new Date(endingDate)
    let dates = []
    //to avoid modifying the original date
    const theDate = new Date(startingDate)
    while (theDate < endingDate) {
      dates = [...dates, new Date(theDate)]
      theDate.setDate(theDate.getDate() + 1)
    }
    dates = [...dates, endingDate]
    return dates
  }

  // grabbing the days scheduled for class and slicing them to first 3 letters, example tue instead of tuesday
  days = days?.map(d => d.slice(0, 3))

  // mapping through students to grab the students that are in the class
  data?.map(c => {
    return tradeStudentsId?.map(t => t === c._id ? allStudents.push(c) : null)
  })

  allStudents.forEach(person => {
    person.class?.forEach(classTaken => {
      if(classTaken.isActive === false){
      } else{

      
      let format = 'hh:mm:ss'
      let sTime = moment(startTime, format)
      let eTime = moment(endTime, format)
      
      // all class times in classroom selected
      let beforeTime = moment(classTaken.startTime, format)
      let afterTime = moment(classTaken.endTime, format)

      // checking if start time or end time conflicts
      if (sTime.isBetween(beforeTime, afterTime) || classTaken.startTime === startTime || eTime.isBetween(beforeTime, afterTime) || afterTime.isBetween(sTime, eTime) || beforeTime.isBetween(sTime, eTime)) {
        
        // gets all days in range of class in session
        let classInSession = getDatesBetweenDates(classTaken.startDate, classTaken.endDate);
        
        // gets all days in range of class to be scheduled
        let classToSchedule = getDatesBetweenDates(startDate, endDate);

        // gets the days of the class that is being taken currently
        let roomDays = classTaken.days.map(d => d.slice(0, 3))
        
        //checking range in session, only pushing the actual days that classes are on
        classInSession.map(c => {
          c = c.toString()
          return roomDays.map(r => c.includes(r) ? classDayInProgress.push(c) : null)
        })
        
        // checking the days the class to be scheduled and only pushing the actual days out of the range
        classToSchedule.map(c => {
          return days.map(d => c.toString().includes(d) ? scheduledDays.push(c) : null)
        })
      
        // checking the actual days to be scheduled against the days that the class are in session and pushing the conflicts
        classDayInProgress.map(c => {
          return scheduledDays.map(d => d.toString() === c.toString() ? conflictedDate.push({name: person.name, class: classTaken.classname, date: new Date(c).toDateString() + ' '}) : null)
        })
      }
    }
    })
  })

  return conflictedDate
}