import { configureStore } from "@reduxjs/toolkit";
import userReducer from './reducers/userSlice';
import getStudentsReducer from "./reducers/getStudentsSlice";
import updateStudentReducer from './reducers/updateStudentSlice';
import createStudentReducer from './reducers/createStudentSlice';
import rssReducer from './reducers/rssSlice';
import modalReducer from './reducers/modalSlice';
import getClassesReducer from './reducers/getClassesSlice';
import updateClassReducer from './reducers/updateClassSlice';
import removeClassReducer from "./reducers/deleteClassSlice";
import addStudentToClassReducer from './reducers/addStudentToClassSlice';
import studentToRemoveFromClassReducer from './reducers/removeStudentFromClassSlice';
import createClassReducer from './reducers/createClassSlice';
import graduateClassReducer from "./reducers/graduateClassSlice";
import removeRequiredClassReducer from './reducers/removeRequiredClassSlice';
import removeTradeClassReducer from "./reducers/removeTradeClassSlice";

export const store = configureStore({
    reducer: {
        getStudents: getStudentsReducer,
        getClasses: getClassesReducer,
        removeClass: removeClassReducer,
        updateStudent: updateStudentReducer,
        updateClass: updateClassReducer,
        createStudent: createStudentReducer,
        createClass: createClassReducer,
        addStudentToClass: addStudentToClassReducer,
        removeStudentFromClass: studentToRemoveFromClassReducer,
        graduateClass: graduateClassReducer,
        modal: modalReducer,
        user: userReducer,
        rss: rssReducer,
        removeRequiredClass: removeRequiredClassReducer,
        removeTradeClass: removeTradeClassReducer,
    }
})
