import { createSlice } from "@reduxjs/toolkit";

export const modalSlice = createSlice({
    name: "modal",
    initialState: {
        isOpen: false,
        message: '',
        id: '',
        type: '',
        payload: '',
        classConflict: [],
        studentConflict: []
    },
    // actions below to modify state
    reducers: {
        openModal: (state, action) => {
            state.isOpen = true;
            state.message = action.payload.message;
            state.type = action.payload.type;
            state.id = action.payload.id;
            state.payload = action.payload.payload;
            state.classConflict = action.payload.classConflict;
            state.studentConflict = action.payload.studentConflict
        },
        closeModal: (state, action) => {
            state.isOpen = false;
            state.message = '';
            state.id = '';
            state.type = '';
            state.payload = ''
        }
    },
});

export const { openModal, closeModal } = modalSlice.actions;

export default modalSlice.reducer;