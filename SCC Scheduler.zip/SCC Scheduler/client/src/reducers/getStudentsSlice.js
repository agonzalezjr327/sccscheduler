import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { routeGetCall } from '../actions/routeService';
import  moment  from 'moment';
import {ModelTypes, ModelActionTypes as Model} from '../constants/types';

export const getAllStudents = createAsyncThunk('students', async (thunkAPI) => {
    try {
        return await routeGetCall(ModelTypes.USER, Model.STUDENTS)
    } catch (err) {
        return thunkAPI.rejectWithValue(err.response.data)
    }
})

export const getStudentsSlice = createSlice({
    name: "getStudents",
    initialState: {
        isLoading: false,
        isActive: [],
        allStudents: [],
        closeToRelease: [],
        rssList: [],
        studentProfile: '',
        tradeStudents: [],
        orientation: [],
        smartJustice: [],
        graduation: [],
        newFreedom: [],
        eventStudents: [],
        eventName: '',
        trade: '',
        graduates: [],
        selectedClass: [],
        temporary: [],
        temporaryArray: [],
        childSupport: [],
        hasDriverLicense: [],
        noDriverLicense: [],
        jobField: [],
        },
    // actions below to modify state
    reducers: {
        getStudentProfile: (state, action) => {
            state.studentProfile = state.allStudents.filter(student => action.payload === student.adc);
        },
        getTradeInfo: (state, action) => {
            state.tradeStudents = state.isActive.filter(student => action.payload.trade?.toLowerCase() === student.trade?.toLowerCase());
            state.trade = action.payload.trade;
        },
        getEventInfo: (state, action) => {
            state.eventStudents = state[`${action.payload.event}`];
            state.eventName = action.payload.eventName;
        },
        getCreatedClass: (state, action) => {
            state.selectedClass = [];
            state.temporaryArray = [];
            state.temporary = [];

            state.closeToRelease.forEach(c => {
                if (c.class === undefined) {
                    state.selectedClass.push(c);
                } else {
                    c.class.forEach(name => {
                        state.temporaryArray.push(name.classname)
                    })

                }
                if (!state.temporaryArray.includes(action.payload)) {
                    state.selectedClass.push(c);
                } else {
                    state.temporary.push(c)
                }
                state.temporaryArray = [];
            })
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(getAllStudents.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(getAllStudents.fulfilled, (state, action) => {

                state.isLoading = false;
                state.allStudents = action.payload.students;

                state.rssList = action.payload.students.filter(data => data.isRSS === true);
                state.isActive = action.payload.students.filter(data => data.isActive === true && data.isRemoved !== true);
                state.isActive = state.isActive.map(active => {
                    if(active.bedSpace === 'released') return active
                    if (active.bedSpace.length > 4) {
                        active.bedSpace = active.bedSpace.split('').splice(3).join('')
                    }
                    return active
                });
                state.childSupport = state.isActive.filter(x => x.hasChildSupport === true);
                state.hasDriverLicense = state.isActive.filter(x => x.hasActiveLicense === true);
                state.noDriverLicense = state.isActive.filter(x => x.hasActiveLicense !== true);
                state.jobField = state.isActive.filter(x => x.jobField !== '' && x.jobField !== undefined);
                state.closeToRelease = state.isActive.sort((a, b) => {
                    let x = moment(a.releaseDate).valueOf()
                    let y = moment(b.releaseDate).valueOf()
                    return x < y ? -1 : x > y ? 1 : 0;
                });
                state.newFreedom = state.closeToRelease.filter(x => x.placeReleasingTo?.toLowerCase() === 'new freedom');
                state.smartJustice = state.closeToRelease.filter(x => x.wioa === true);

                state.closeToRelease.forEach(x => {
                    let temp = [];
                    x.class?.forEach(c => {
                        temp.push(c.classname);
                    });
                    if(!temp.includes('Graduation')){
                        state.graduation.push(x);
                    } 
                    temp = []; 
                });
                // code below is removing duplicates from array of objects
                state.graduation = state.graduation.filter((v,i,a) => a.findIndex(v2 => (v2.adc === v.adc)) === i)
                state.orientation = state.closeToRelease.filter(x => x.orientation === undefined || x.orientation === true);
                state.graduates = state.allStudents.filter(x => x.isGraduated === true);
                state.selectedClass = [];

            })
            .addCase(getAllStudents.rejected, (state, action) => {
                state.isLoading = false;
            })
    }
});

export const { getStudentProfile, getTradeInfo, getEventInfo, getCreatedClass } = getStudentsSlice.actions;

export default getStudentsSlice.reducer;