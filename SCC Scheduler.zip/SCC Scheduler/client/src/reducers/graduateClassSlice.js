import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { routePostCall } from '../actions/routeService';
import { toast } from 'react-toastify';
import {ModelTypes, ModelActionTypes as Model} from '../constants/types';

export const graduateActiveClass = createAsyncThunk('graduateClass', async (payload, thunkAPI) => {
    try {
        return await routePostCall(payload, ModelTypes.CLASS, Model.GRADUATE_CLASS)
    } catch (err) {
        return thunkAPI.rejectWithValue(err.response.data)
    }
})

export const graduateClassSlice = createSlice({
    name: "graduateClass",
    initialState: {
        isLoading: false,
        msg: '',
        
    },
    // actions below to modify state
    reducers: {
     
    },
    extraReducers: (builder) => {
        builder
            .addCase(graduateActiveClass.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(graduateActiveClass.fulfilled, (state, action) => {
                state.isLoading = false;
                state.msg = action.payload.msg;
                toast.success(action.payload.msg, { position: 'top-center' });
            })
            .addCase(graduateActiveClass.rejected, (state, action) => {
                state.isLoading = false;
            })
    }
});

export default graduateClassSlice.reducer;