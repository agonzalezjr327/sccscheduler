import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { toast } from 'react-toastify';
import { routePostCall } from "../actions/routeService";
import {ModelTypes, ModelActionTypes as Model} from '../constants/types';

export const create = createAsyncThunk('createStudent', async (payload, thunkAPI) => {
    try {
        return await routePostCall(payload, ModelTypes.USER, Model.CREATE_STUDENT)
    } catch (err) {
        return thunkAPI.rejectWithValue(err.response.data)
    }
});

export const createStudentSlice = createSlice({
    name: "createStudent",
    initialState: {
        isLoading: false,
        msg: '',
        error: false,
    },
    // actions below to modify state
    reducers: {
    
    },
    extraReducers: (builder) => {
        builder
            .addCase(create.pending, (state) => {
                state.error = false;
                state.isLoading = true;
            })
            .addCase(create.fulfilled, (state, action) => {
                state.error = false;
                state.msg = action.payload.msg;
                state.isLoading = false;
                toast.success(action.payload.msg, { position: 'top-center' })
            })
            .addCase(create.rejected, (state, action) => {
                state.error = true;
                state.isLoading = false;
                state.msg = action.payload.msg;
                toast.error(action.payload.msg, { position: 'top-center' });
            })
    }
});

export default createStudentSlice.reducer;