import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { routePostCall } from '../actions/routeService';
import { toast } from 'react-toastify';
import {ModelTypes, ModelActionTypes as Model} from '../constants/types';

export const removeRequiredClass = createAsyncThunk('removeRequiredCLass', async (payload, thunkAPI) => {
    try {
        return await routePostCall(payload, ModelTypes.CLASS, Model.REMOVE_REQUIRED_CLASS)
    } catch (err) {
        return thunkAPI.rejectWithValue(err.response.data)
    }
});

export const removeRequiredClassSlice = createSlice({
    name: "removeRequiredClass",
    initialState: {
        isLoading: false,
        msg: '',
        error: false,
    },
    // actions below to modify state
    reducers: {
    
    },
    extraReducers: (builder) => {
        builder
            .addCase(removeRequiredClass.pending, (state) => {
                state.error = false;
                state.isLoading = true;
            })
            .addCase(removeRequiredClass.fulfilled, (state, action) => {
                state.error = false;
                state.msg = action.payload.msg;
                state.isLoading = false;
                toast.success(action.payload.msg, { position: 'top-center' })
            })
            .addCase(removeRequiredClass.rejected, (state, action) => {
                state.error = true;
                state.isLoading = false;
                state.msg = action.payload.msg;
                toast.error(action.payload.msg, { position: 'top-center' });
            })
    }
});

export default removeRequiredClassSlice.reducer;