import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { toast } from 'react-toastify';
import { routePostCall } from "../actions/routeService";
import {ModelTypes, ModelActionTypes as Model} from '../constants/types';

export const login = createAsyncThunk('login', async (payload, thunkAPI) => {
    try {
        return await routePostCall(payload, ModelTypes.USER, Model.SIGN_IN)
    } catch (err) {
        return thunkAPI.rejectWithValue(err.response.data)
    }
});

export const userSlice = createSlice({
    name: "user",
    initialState: {
        isLoading: false,
        isAuth: false,
        isActive: '',
        msg: '',
        error: false,
        token: ''
    },
    // actions below to modify state
    reducers: {
        setLogout: (state) => {
            localStorage.removeItem("token");
            toast.info(`Admin has logged out`);
            state.token = null;
            state.isAuth = false;
            state.isLoading = false;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(login.pending, (state) => {
                state.error = false;
                state.isLoading = true;
            })
            .addCase(login.fulfilled, (state, action) => {
                state.error = false;
                localStorage.setItem("token", action.payload.token);
                state.isAuth = action.payload.isAuth; 
                state.msg = action.payload.msg;
                state.isLoading = false;
                state.token = action.payload.token;
                toast.success(action.payload.msg, { position: 'top-center' })
            })
            .addCase(login.rejected, (state, action) => {
                state.error = true;
                state.isAuth = action.payload.isAuth;
                state.isLoading = false;
                state.msg = action.payload.msg;
                toast.error(action.payload.msg, { position: 'top-center' });
            })
    }
});

export const { setLogout } = userSlice.actions;

export default userSlice.reducer;