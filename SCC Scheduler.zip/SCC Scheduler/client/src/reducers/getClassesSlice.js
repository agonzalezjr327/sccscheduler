import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { routeGetCall } from '../actions/routeService';
import moment from 'moment';
import {ModelTypes, ModelActionTypes as Model} from '../constants/types';


export const getAllClasses = createAsyncThunk('classes', async (thunkAPI) => {
    try {
        return await routeGetCall(ModelTypes.CLASS, Model.CLASSES)
    } catch (err) {
        return thunkAPI.rejectWithValue(err.response.data)
    }
})

export const getClassesSlice = createSlice({
    name: "getClasses",
    initialState: {
        isLoading: false,
        isActive: [],
        classes: [],
        completedClasses: [],
        allGraduatedClasses: [],
        requiredClasses: [],
        tradeClasses: [],
        classInfo: ''
    },
    // actions below to modify state
    reducers: {
        getClassInfo: (state, action) => {
            state.classInfo = state.classes.filter(classes => action.payload.courseId === classes._id);
        },
        removeFromRequiredClasses: (state, action) => {
            state.requiredClasses = state.requiredClasses.filter(classes => classes !== action.payload.payload);
        },
        removeFromTradeClasses: (state, action) => {
            state.tradeClasses = state.tradeClasses.filter(classes => classes !== action.payload.payload);
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(getAllClasses.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(getAllClasses.fulfilled, (state, action) => {
                state.isLoading = false;
                state.classes = action.payload.classes;
                state.completedClasses = action.payload.classes.filter(data => data.isActive === false);
                state.completedClasses = state.completedClasses.sort((a, b) => {
                    let x = moment(b.endDate).valueOf()
                    let y = moment(a.endDate).valueOf()
                    return x < y ? -1 : x > y ? 1 : 0;
                });
                state.classes = state.classes.sort((a, b) => {
                    let x = a.startTime
                    let y = b.startTime
                    return x < y ? -1 : x > y ? 1 : 0;
                });
                state.classes = state.classes.sort((a, b) => {
                    let x = a.classroom.toLowerCase();
                    let y = b.classroom.toLowerCase();
                    return x < y ? -1 : x > y ? 1 : 0;
                });
                state.isActive = action.payload.classes.filter(data => data.isActive === true);
                state.classes.forEach(data => {
                    if(data.isRequired === true && !state.requiredClasses.includes(data.classname)){
                        state.requiredClasses.push(data.classname)
                    }
                });
                state.classes.forEach(data => {
                    if(data.isTrade === true && !state.tradeClasses.includes(data.classname)){
                        state.tradeClasses.push(data.classname)
                    }
                });
                state.allGraduatedClasses = state.classes.filter(c =>  c.classname.toLowerCase() === 'graduation');
                
            })
            .addCase(getAllClasses.rejected, (state, action) => {
                state.isLoading = false;
            })
    }
});

export const { getClassInfo, removeFromRequiredClasses, removeFromTradeClasses } = getClassesSlice.actions;

export default getClassesSlice.reducer;