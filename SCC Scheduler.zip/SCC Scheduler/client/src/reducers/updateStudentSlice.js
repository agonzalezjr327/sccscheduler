import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { toast } from 'react-toastify';
import { routePostCall } from "../actions/routeService";
import {ModelTypes, ModelActionTypes as Model} from '../constants/types';

export const update = createAsyncThunk('updateStudent', async (payload, thunkAPI) => {
    try {
        return await routePostCall(payload, ModelTypes.USER, Model.UPDATE_STUDENT)
    } catch (err) {
        return thunkAPI.rejectWithValue(err.response.data)
    }
});

export const updateStudentSlice = createSlice({
    name: "updateStudent",
    initialState: {
        isLoading: false,
        msg: '',
        error: false,
    },
    // actions below to modify state
    reducers: {
    
    },
    extraReducers: (builder) => {
        builder
            .addCase(update.pending, (state) => {
                state.error = false;
                state.isLoading = true;
            })
            .addCase(update.fulfilled, (state, action) => {
                state.error = false;
                state.msg = action.payload.msg;
                state.isLoading = false;
                toast.success(action.payload.msg, { position: 'top-center' })
            })
            .addCase(update.rejected, (state, action) => {
                state.error = true;
                state.isLoading = false;
                state.msg = action.payload.msg;
                toast.error(action.payload.msg, { position: 'top-center' });
            })
    }
});

export default updateStudentSlice.reducer;