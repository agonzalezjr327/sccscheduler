import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { toast } from 'react-toastify';
import { routePostCall } from "../actions/routeService";
import {ModelTypes, ModelActionTypes as Model} from '../constants/types';

export const classUpdate = createAsyncThunk('updateClass', async (payload, thunkAPI) => {
    try {
        return await routePostCall(payload, ModelTypes.CLASS, Model.UPDATE_CLASS)
    } catch (err) {
        return thunkAPI.rejectWithValue(err.response.data)
    }
});

export const updateClassSlice = createSlice({
    name: "updateClass",
    initialState: {
        isLoading: false,
        msg: '',
        error: false,
    },
    // actions below to modify state
    reducers: {
    
    },
    extraReducers: (builder) => {
        builder
            .addCase(classUpdate.pending, (state) => {
                state.error = false;
                state.isLoading = true;
            })
            .addCase(classUpdate.fulfilled, (state, action) => {
                state.error = false;
                state.msg = action.payload.msg;
                state.isLoading = false;
                toast.success(action.payload.msg, { position: 'top-center' })
            })
            .addCase(classUpdate.rejected, (state, action) => {
                state.error = true;
                state.isLoading = false;
                state.msg = action.payload.msg;
                toast.error(action.payload.msg, { position: 'top-center' });
            })
    }
});

export default updateClassSlice.reducer;